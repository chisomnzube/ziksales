<?php $__env->startSection('head'); ?>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="Ziksales, Best E-commerce Site In Nigeria, I want to Buy, about Phones and Tablets, Men's fashion, Women's fashion, Electronics, Health and Beauty, Computing, Grocery, Sporting Goods, Home and Kitchen. ">
    <meta name="description" content="My Compare. Ziksales is an excellent E-commerce platform that makes buying and selling easy. We give you a safe, comfortable, secure and excellent shopping experience. We deal on products like Phones and Tablets, Men's fashion, Women's fashion, Electronics, Health and Beauty, Computing, Grocery, Sporting Goods, Home and Kitchen. Feel free shopping with us.">

    <!-- FONT  -->
    <!-- <link rel="stylesheet" href="../fonts/fira-sans.css"> -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Fira+Sans">

    <!-- REQUIRED CSS: BOOTSTRAP, FONTAWESOME, PERFECT-SCROLLBAR  -->
    <link rel="stylesheet" href="../dist/css/vendor.min.css">


    <!-- Mimity CSS  -->
    <link rel="stylesheet" href="../dist/css/style.min.css">


    <title>Compare | <?php echo e(config('app.name')); ?></title>
  </head>
<?php $__env->stopSection(); ?>  


<?php $__env->startSection('main-content'); ?>

        <div class="col" id="main-content">
            <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <h3>Product Comparison</h3>
<?php if(Cart::instance('compare')->count() > 0): ?>
          <div class="table-responsive">
            <table class="table table-bordered text-center table-wishlist">
              <thead>
                <tr>
                  
                  <?php $__currentLoopData = Cart::instance('compare')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <th>
                    <p><a href="detail.html"><img src="<?php echo e(productImage($item->model->image)); ?>" width="75" height="75" alt="<?php echo e($item->model->name); ?> - <?php echo str_limit($item->model->details, 30); ?>"></a></p>
                    <p><a href="detail.html" class="text-body"><?php echo e($item->model->name); ?> - <?php echo str_limit($item->model->details, 30); ?></a></p>
                    <div class="btn-group btn-group-sm" role="group">
                      <form action="<?php echo e(route('compare.switchToCart', $item->rowId)); ?>" method="POST">
                          <?php echo e(csrf_field()); ?>

                      <button type="submit" class="btn btn-outline-info">Add to cart</button>
                      </form>
                    </div>
                  </th>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
                  
                  
                </tr>
              </thead>
              <tbody>
                <tr>

                <?php $__currentLoopData = Cart::instance('compare')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <td>
                    <strong>Price:</strong>
                    <div>&#8358;<?php echo e(number_format( totalcash($item->model->price, $item->model->profit) )); ?></div>
                  </td>      
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                  
                </tr>
                
                <tr>
                  <?php $__currentLoopData = Cart::instance('compare')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <td>                    
                    <div class="btn-group btn-group-sm" role="group">
                       <form action="<?php echo e(route('compare.destroy', $item->rowId)); ?>" method="POST">
                          <?php echo e(csrf_field()); ?>

                          <?php echo e(method_field('DELETE')); ?>

                      <button type="submit" class="btn btn-outline-info">Remove</button>
                      </form>
                    </div>
                  </td>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                  
                </tr>
              </tbody>
            </table>
          </div>
<?php endif; ?>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>  


<?php $__env->startSection('required-js'); ?>
    <!-- REQUIRED JS  -->
    <script src="../plugins/jquery/jquery.min.js"></script>
    <script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>


    <!-- Mimity JS  -->
    <script src="../dist/js/script.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ziksdxfh/ziksales/resources/views/compare.blade.php ENDPATH**/ ?>