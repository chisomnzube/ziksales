<!doctype html>
<html lang="en">

<?php echo $__env->yieldContent('head'); ?>

<body>

  <!-- Sidebar -->
  <div class="sidebar">

    <!-- Sidebar header -->
    <div class="sidebar-header">
      <a href="<?php echo e(route('agent.index')); ?>" class="logo">
        Agent Portal
      </a>
      <a href="#" class="nav-link nav-icon rounded-circle ml-auto" data-toggle="sidebar">
        <i class="material-icons">close</i>
      </a>
    </div>
    <!-- /Sidebar header -->

    <!-- Sidebar body -->
    <div class="sidebar-body">
      <ul class="nav nav-sub">
        <li class="nav-label">DASHBOARD</li>
        <li class="nav-item">
          <a class="nav-link has-icon active" href="<?php echo e(route('agent.index')); ?>"><i data-feather="bar-chart-2"></i>Agent Statistics</a>
        </li>
        <li class="nav-item">
          <a class="nav-link has-icon" href="<?php echo e(route('agent.orders')); ?>"><i data-feather="database"></i>Agent Order(s)</a>
        </li>
        <li class="nav-item">
          <a class="nav-link has-icon" href="<?php echo e(route('agent.wallet')); ?>"><i data-feather="dollar-sign"></i>My Wallet</a>
        </li>
        <li class="nav-item">
          <a class="nav-link has-icon" href="<?php echo e(route('agent.bank')); ?>"><i data-feather="credit-card"></i>My Bank</a>
        </li>
        
        
      </ul>
    </div>
    <!-- /Sidebar body -->

  </div>
  <!-- /Sidebar -->

  <!-- Main -->
  <div class="main">

    <!-- Main header -->
    <div class="main-header">
      <a class="nav-link nav-link-faded rounded-circle nav-icon" href="#" data-toggle="sidebar"><i class="material-icons">menu</i></a>
      
      
    </div>
    <!-- /Main header -->

<?php echo $__env->yieldContent('main-content'); ?>

  </div>
  <!-- /Main -->

  <!-- Search Modal -->
  <div class="modal" id="searchModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-body p-1 p-lg-3">
          <form>
            <div class="input-group input-group-lg input-group-search">
              <div class="input-group-prepend">
                <button class="btn text-secondary btn-icon btn-lg" type="button" data-dismiss="modal">
                  <i class="fa fa-chevron-left"></i>
                </button>
              </div>
              <input type="text" class="form-control form-control-lg border-0 mx-1 px-0 px-lg-3" placeholder="Search..." autocomplete="off" required autofocus>
              <div class="input-group-append">
                <button class="btn text-secondary btn-icon btn-lg" type="submit">
                  <i class="fa fa-search"></i>
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <!-- /Search Modal -->

  <?php echo $__env->yieldContent('script'); ?>

</body>

</html><?php /**PATH /home/ziksdxfh/ziksales/resources/views/layouts/dashboard.blade.php ENDPATH**/ ?>