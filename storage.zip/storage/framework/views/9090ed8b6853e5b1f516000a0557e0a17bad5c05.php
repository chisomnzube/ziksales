<?php $__env->startSection('head'); ?>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="<?php echo e($product->keywords); ?>">
    <meta name="description" content="<?php echo e($product->name); ?> is in <?php echo e($subName); ?> category and it's features are <?php echo $product->details; ?>">
    <meta property="og:image" content="<?php echo e(productImage($product->image)); ?>">

    <!-- FONT  -->
    <!-- <link rel="stylesheet" href="../fonts/fira-sans.css"> -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Fira+Sans">

    <!-- REQUIRED CSS: BOOTSTRAP, FONTAWESOME, PERFECT-SCROLLBAR  -->
    <link rel="stylesheet" href="<?php echo e(asset('../dist/css/vendor.min.css')); ?>">


    <!-- PLUGINS FOR CURRENT PAGE -->
    <link rel="stylesheet" href="<?php echo e(asset('../plugins/swiper/swiper.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('../plugins/photoswipe/photoswipe.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('../plugins/photoswipe/photoswipe-default-skin/default-skin.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/starability-minified/starability-all.min.css')); ?>"/>

    <!-- Mimity CSS  -->
    <link rel="stylesheet" href="<?php echo e(asset('../dist/css/style.min.css')); ?>">


    <title><?php echo e($product->name); ?> :- <?php echo str_limit($product->details, 30); ?> | <?php echo e(config('app.name')); ?></title>
    
    <style>
        width:100%;
        @media (max-width: 720px) {
            .dimg {
                height: 120px;
            }
        }
        @media (min-width: 730px) {
            .dimg {
                height: 230px;
            }
        }
    </style>
  </head>
<?php $__env->stopSection(); ?>  
  
<?php $__env->startSection('main-content'); ?>

        <div class="col" id="main-content">
          <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <!-- Breadcrumb -->
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('landing-page')); ?>" class="text-info">Home</a></li>
              <li class="breadcrumb-item"><a  class="text-info"><?php echo e($subName); ?></a></li>
              <li class="breadcrumb-item active" aria-current="page"><?php echo e($product->name); ?></li>
            </ol>
          </nav>
          <!-- /Breadcrumb -->

          <div class="row">
            <div class="col-md-7">
              <div class="img-detail-wrapper">
                <img src="<?php echo e(productImage($product->image)); ?>" class="img-fluid px-5" id="img-detail" alt="<?php echo e($product->name); ?>- <?php echo str_limit($product->details, 30); ?>" data-index="0">
                <div class="img-detail-list">
                  <a href="#" class="active"><img src="<?php echo e(productImage($product->image)); ?>" data-large-src="<?php echo e(productImage($product->image)); ?>" alt="<?php echo e(productImage($product->image)); ?>" data-index="0"></a>

                  <?php if($product->images): ?>
                    
                      <?php $__currentLoopData = json_decode($product->images, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="#"><img src="<?php echo e(productImage($image)); ?>" data-large-src="<?php echo e(productImage($image)); ?>" alt="<?php echo e(productImage($image)); ?>" data-index="
                          <?php for($i = 1; $i <= count( json_decode($product->images, true) ); $i++): ?>
                                <?php echo e($i); ?>

                          <?php endfor; ?>       
                          "></a>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     
                  <?php endif; ?>
                  
                </div>
              </div>
            </div>
            <div class="col-md-5">
              <div class="detail-header">
                <h3><?php echo e($product->name); ?></h3>
                <h3 class="price">&#8358;<?php echo e(number_format(totalcash($product->price, $product->profit) )); ?></h3>
                    <div class="form-group mb-4">
                      <div class="btn-group btn-group-sm btn-group-toggle" data-toggle="buttons">
                        
                          <?php echo $stockLevel; ?>

                        
                      </div>
                    </div>
              </div>
              <form>
                <div class="form-group">
                    
                  <label class="d-block"><b>Details</b></label>
                  <div class="btn-group btn-group-sm btn-group-toggle" data-toggle="buttons">
                    
                      <p><?php echo $product->details; ?></p>
                    
                  </div>
                </div>
               
              </form>
              <form>
                <div class="form-group">
                    
                  <label class="d-block"><b>Delivery Information</b></label>
                  <div class="btn-group btn-group-sm btn-group-toggle" data-toggle="buttons">
                    
                      <p><?php echo e(getDeliveryDay($product->delivery_info)); ?></p>
                    
                  </div>
                </div>
               
              </form>

              <?php if($product->quantity > 0): ?>
                <form action="<?php echo e(route('cart.store')); ?>" method="POST">
                  <?php echo e(csrf_field()); ?>

                  <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                  <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
                  <input type="hidden" name="price" value="<?php echo e(totalcash($product->price, $product->profit)); ?>">
                    <div class="form-group">
                      <button type="submit" class="btn btn-info btn-block">ADD TO CART</button>
                    </div>
                </form>
              <?php endif; ?>  
              <div class="row">
                  <div class="col-md-6" style="margin:5px;">
                      <a class="btn btn-block" style="background-color: #ff6600; color:white;" href="https://wa.me/2347031382795?text=Hello Mr. Ziksales, I will like to order for this item <?php echo e($product->name); ?> - <?php echo str_limit($product->details, 30); ?> as seen on <?php echo e(url()->current()); ?>"><i data-feather="whatsapp" class="fa fa-whatsapp"></i> Order on Whatsapp</a>
                  </div>
                  <div class="col-md-5" style="margin:5px;">
                      <form action="<?php echo e(route('compare.store')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                        <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
                        <input type="hidden" name="price" value="<?php echo e(totalcash($product->price, $product->profit)); ?>">
                          <div class="form-group">
                            <button type="submit" class="btn btn-block" style="background-color: #ff6600; color:white;">Add To Compare</button>
                          </div>
                      </form>
                  </div>
              </div>
              <hr>
              <div class="d-flex align-items-center">
                <span class="text-muted">Share</span>
                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url()->current()); ?>" class="btn btn-light btn-icon rounded-circle border ml-2" data-toggle="tooltip" title="Facebook" target="_blank"><i data-feather="facebook" class="fa fa-facebook"></i></a>
                <a href="https://twitter.com/intent/tweet?text=Check out <?php echo e($product->name.' '.str_limit($product->details, 100).' - Click on the link '); ?><?php echo e(url()->current()); ?>" class="btn btn-light btn-icon rounded-circle border ml-2" data-toggle="tooltip" title="Twitter"><i data-feather="twitter" class="fa fa-twitter" target="_blank"></i></a>
                <a href="https://wa.me/?text=Check out <?php echo e($product->name.' '.str_limit($product->details, 100).' - Click on the link '); ?><?php echo e(url()->current()); ?>" class="btn btn-light btn-icon rounded-circle border ml-2" data-toggle="tooltip" title="Whatsapp" target="_blank"><i data-feather="whatsapp" class="fa fa-whatsapp"></i></a>
              </div>
            </div>
          </div>
          <hr>
          <div class="row mt-4">
            <div class="col">
              <h3>Description</h3>
              <?php echo $product->description; ?>

              
              <hr>

              <!-- Similar Items -->
              <h3>Similar <?php echo $subName; ?></h3>
              <div class="content-slider">
            <div class="swiper-container" id="popular-slider">
              <div class="swiper-wrapper">

                <div class="swiper-slide">
                  <div class="row no-gutters gutters-2">

                    <?php $__currentLoopData = $relaProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relaProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-4 col-md-4 mb-2">
                      <div class="card card-product" style="height: 100%; width: 100%;">
                        <?php echo $product->quantity < setting('site.stock_threshold') ? '<div class="badge badge-danger badge-pill">Only '.$product->quantity.' left in stock</div>' : ''; ?>        
                        <a href="<?php echo e(route('shop.show', $relaProduct->slug)); ?>"><img src="<?php echo e(productImage($relaProduct->image)); ?>" alt="<?php echo e($relaProduct->name); ?> :- <?php echo str_limit($relaProduct->details, 30); ?>" class="card-img-top dimg"></a>
                        <div class="card-body">
                          <span class="price"> &#8358;<?php echo e(number_format( totalcash($relaProduct->price, $relaProduct->profit) )); ?></span>
                          <a href="<?php echo e(route('shop.show', $relaProduct->slug)); ?>" class="card-title h6"><?php echo e($relaProduct->name); ?> - <?php echo str_limit($relaProduct->details, 30); ?></a>
                          
                        </div>
                      </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </div>
                </div>
                
               
                
              </div>
            </div>
           
          </div>
              <!-- /Similar Items -->

              <hr>
              <h3 id="reviews">Reviews</h3>
              

              <?php if($reviews->count() > 0): ?>
              <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="media">
                <div class="media-body ml-3">
                  <h5 class="mb-0"><?php echo e($review->user_name); ?></h5>
                  <p class="starability-result" data-rating="<?php echo e($review->rating); ?>">
                    Rated: <?php echo e($review->rating); ?> stars
                  </p>
                  
                  <p><?php echo e($review->review); ?></p>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <?php else: ?>
                <h6>No Review yet!</h6>
              <?php endif; ?>
              

            </div>
          </div>

        

    <!-- Photoswipe container-->
    <div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="pswp__bg"></div>
      <div class="pswp__scroll-wrap">
        <div class="pswp__container">
          <div class="pswp__item"></div>
          <div class="pswp__item"></div>
          <div class="pswp__item"></div>
        </div>
        <div class="pswp__ui pswp__ui--hidden">
          <div class="pswp__top-bar">
            <div class="pswp__counter"></div>
            <button class="pswp__button pswp__button--close" title="Close (Esc)"></button>
            <button class="pswp__button pswp__button--share" title="Share"></button>
            <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button>
            <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>
            <div class="pswp__preloader">
              <div class="pswp__preloader__icn">
                <div class="pswp__preloader__cut">
                  <div class="pswp__preloader__donut"></div>
                </div>
              </div>
            </div>
          </div>
          <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
            <div class="pswp__share-tooltip"></div>
          </div>
          <button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)"></button>
          <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)"></button>
          <div class="pswp__caption">
            <div class="pswp__caption__center"></div>
          </div>
        </div>
      </div>
    </div>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php $__env->stopSection(); ?>
   

<?php $__env->startSection('required-js'); ?>
    <!-- REQUIRED JS  -->
    <script src="<?php echo e(asset('../plugins/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../plugins/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>


    <!-- PLUGINS FOR CURRENT PAGE -->
    <script src="<?php echo e(asset('../plugins/swiper/swiper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../plugins/raty-fa/jquery.raty-fa.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../plugins/photoswipe/photoswipe.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../plugins/photoswipe/photoswipe-ui-default.min.js')); ?>"></script>

    <!-- Mimity JS  -->
    <script src="<?php echo e(asset('../dist/js/script.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ziksdxfh/ziksales/resources/views/detail.blade.php ENDPATH**/ ?>