<?php $__env->startSection('head'); ?>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="Ziksales Blog, Best E-commerce Site In Nigeria, I want to Buy, about Phones and Tablets, Men's fashion, Women's fashion, Electronics, Health and Beauty, Computing, Grocery, Sporting Goods, Home and Kitchen. ">
    <meta name="description" content="My Blog - Ziksales. Ziksales is an excellent E-commerce platform that makes buying and selling easy. We give you a safe, comfortable, secure and excellent shopping experience. We deal on products like Phones and Tablets, Men's fashion, Women's fashion, Electronics, Health and Beauty, Computing, Grocery, Sporting Goods, Home and Kitchen. Feel free shopping with us.">
  
    <!-- FONTS  -->
    <!-- <link rel="stylesheet" href="../fonts/nunito.css"> -->
    <!-- <link rel="stylesheet" href="../fonts/roboto.css"> -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700">

    <!-- REQUIRED CSS: BOOTSTRAP, METISMENU, PERFECT-SCROLLBAR  -->
    <link rel="stylesheet" href="../dist/css/vendor.min.css">


    <!-- Mimity CSS  -->
    <link rel="stylesheet" href="../dist/css/style.min.css">

    <title>Blog | <?php echo e(config('app.name')); ?></title>
  </head>
 <?php $__env->stopSection(); ?> 
 

<?php $__env->startSection('main-content'); ?>
    <!-- Main Content -->
    <div class="container my-3">
      <div class="row">

        <div class="col">

          <!-- Blog Toolbar -->
          
          <!-- /Blog Toolbar -->

          <!-- Blog List -->
          <?php if($posts->count() > 0): ?>

          <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card card-blog card-blog-list mt-3">
            <a href="<?php echo e(route('blog.show', $post->slug)); ?>" class="zoom-hover"><img style="width:100%; height:100%;" data-height="100%" src="<?php echo e(productImage($post->image)); ?>"></a>
            <div class="card-body">
              <a href="<?php echo e(route('blog.show', $post->slug)); ?>" class="title h4"><?php echo $post->title; ?></a>
              <p class="d-none d-sm-block"><?php echo str_limit($post->body, 150); ?><a href="<?php echo e(route('blog.show', $post->slug)); ?>">Read more...</a></p>
              <div class="small text-muted counter">
                <i data-feather="" class="fa fa-comment"></i> <?php echo e(countComment($post->id)); ?>

              </div>
            </div>
          </div>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php else: ?>
          <p>No Post yet!</p>
          <?php endif; ?>
         
          <!-- /Blog List -->

          <!-- Pagination -->
          <div class="card card-pagination mt-3">
            <div class="card-body">
              <a href="javascript:void(0)" class="btn btn-link btn-icon"><i data-feather="chevron-left"></i></a>
              <div class="d-inline-flex">
                <?php echo e($posts->appends(request()->input())->links()); ?>


              </div>
              <a href="javascript:void(0)" class="btn btn-link btn-icon"><i data-feather="chevron-right"></i></a>
            </div>
          </div>
          <!-- /Pagination -->

        </div>

        <!-- Blog Sidebar -->
        <div class="col-md-4 col-lg-4 mt-3 mt-md-0">
          <div class="card">
            <div class="card-header bg-white border-bottom bold roboto-condensed">
              <h5 class="bold mb-0">POPULAR THIS <span class="text-primary">WEEK</span></h5>
            </div>
            <div class="card-body">

              <div class="row">
                
                <?php if($populars->count() > 0): ?>
                <?php $__currentLoopData = $populars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-sm-6 col-md-12">
                  <div class="card card-blog shadow-none">
                    <a href="<?php echo e(route('blog.show', $popular->slug)); ?>" class="zoom-hover"><img style="width: 100%; height: 100%;" src="<?php echo e(productImage($popular->image)); ?>" alt="<?php echo $popular->title; ?>"></a>
                    <div class="card-body p-0 text-center">
                      <a href="<?php echo e(route('blog.show', $popular->slug)); ?>" class="title h5 mt-3"><?php echo $popular->title; ?></a>
                      <div class="small text-muted">
                        <i data-feather="message-square" class="ml-3"></i> <?php echo e(countComment($popular->id)); ?> Comments
                      </div>
                    </div>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <p>No Popular Post this week</p>
                <?php endif; ?>
              </div>

            </div>
          </div>

        </div>
        <!-- /Blog Sidebar -->

      </div>
    </div>
    <!-- /Main Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('required-js'); ?>
    <!-- REQUIRED JS  -->
    <script src="../plugins/jquery/jquery.min.js"></script>
    <script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../plugins/feather-icons/feather.min.js"></script>
    <script src="../plugins/metismenu/metisMenu.min.js"></script>
    <script src="../plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>

    <!-- Mimity JS  -->
    <script src="../dist/js/script.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ziksdxfh/ziksales/resources/views/blog-list.blade.php ENDPATH**/ ?>