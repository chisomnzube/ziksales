<?php
namespace App\Http\Controllers;

use App\Category;
use App\CategorySub;
$categories = Category::all();
$allSubCategories = CategorySub::all();
?>

<?php $__env->startSection('head'); ?>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="Ziksales, Best E-commerce Site In Nigeria, I want to Buy, about Phones and Tablets, Men's fashion, Women's fashion, Electronics, Health and Beauty, Computing, Grocery, Sporting Goods, Home and Kitchen. ">
    <meta name="description" content="This is 404 Page. Ziksales is an excellent E-commerce platform that makes buying and selling easy. We give you a safe, comfortable, secure and excellent shopping experience. We deal on products like Phones and Tablets, Men's fashion, Women's fashion, Electronics, Health and Beauty, Computing, Grocery, Sporting Goods, Home and Kitchen. Feel free shopping with us. ">
    <link rel='shortcut icon' type='image/ico' href='<?php echo e(asset('img/blog/ziksaleslogo.ico')); ?>' /> 
    <!-- FONT  -->
    <!-- <link rel="stylesheet" href="../fonts/fira-sans.css"> -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Fira+Sans">

    <!-- REQUIRED CSS: BOOTSTRAP, FONTAWESOME, PERFECT-SCROLLBAR  -->
    <link rel="stylesheet" href="../dist/css/vendor.min.css">


    <!-- Mimity CSS  -->
    <link rel="stylesheet" href="../dist/css/style.min.css">


    <title>How to sell on Ziksales | <?php echo e(config('app.name')); ?></title>
    <style >
      @media (max-width: 720px) {
            img {
                width: 70%;
            }
        }
    </style>
  </head>
<?php $__env->stopSection(); ?>  

<?php $__env->startSection('main-content'); ?>

        <div class="col" id="main-content">

          <!-- 404 Content -->
          <div class="text-center">
            <h1>How to sell on Ziksales</h1>
            <hr>           
             <p> The process of becoming a seller in ziksales is easier. You have the opportunity to make tons of sales using our platform free of charge.</p>
              <h5>Step 1 - Register as a user</h5>
              <p>You have to first of all register as a user in the platform. Follow this link to register <a href="<?php echo e(route('register')); ?>">Click Here</a>. <i>Skip if your are already a registered user.</i> </p>
              <h5>Step 2 - Register as a seller</h5>
              <p>After you have registered as a user, now you can register as a seller by filling in the categories of products you sell and the location of those products. Follow this link to register as a seller <a href="<?php echo e(route('seller.register')); ?>">Click Here</a> OR after registering as a user, click the User Icon at the top right corner of the website and select "Seller's portal"</p>
              <img src="<?php echo e(asset('img/user-icon2.jpg')); ?>"><br><br>
              <h5>Step 3 - Upload your products</h5>
              <p>When you are done registering as a seller, you will be taken to a page where you will see  a button "Add Products", click the button and start uploading the products to the website. </p>
              <img src="<?php echo e(asset('img/add-product.jpg')); ?>">
              <p>Get your products out to the market and make tons of sales.</p>


              <a class="btn btn-outline-info" href="javascript:history.back()" role="button"><i class="fa fa-arrow-left"></i> Go Back</a>
              <a class="btn " href="<?php echo e(route('landing-page')); ?>" role="button" style="background-color: #ff751a; color: white;"><i class="fa fa-home"></i> Home</a>
            
            
          </div>
          <!-- /404 Content -->

<?php $__env->stopSection(); ?>        
      </div>
    </div>

<?php $__env->startSection('required-js'); ?>
    <!-- REQUIRED JS  -->
    <script src="../plugins/jquery/jquery.min.js"></script>
    <script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>


    <!-- Mimity JS  -->
    <script src="../dist/js/script.min.js"></script>
<?php $__env->stopSection(); ?>
  </body>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ziksdxfh/ziksales/resources/views/how-seller.blade.php ENDPATH**/ ?>