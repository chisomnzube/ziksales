<?php $__env->startSection('head'); ?>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="Ziksales wishlist, Best E-commerce Site In Nigeria, I want to Buy, about Phones and Tablets, Men's fashion, Women's fashion, Electronics, Health and Beauty, Computing, Grocery, Sporting Goods, Home and Kitchen. ">
    <meta name="description" content="My Wishlist. Ziksales is an excellent E-commerce platform that makes buying and selling easy. We give you a safe, comfortable, secure and excellent shopping experience. We deal on products like Phones and Tablets, Men's fashion, Women's fashion, Electronics, Health and Beauty, Computing, Grocery, Sporting Goods, Home and Kitchen. Feel free shopping with us.">

    <!-- FONT  -->
    <!-- <link rel="stylesheet" href="../fonts/fira-sans.css"> -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Fira+Sans">

    <!-- REQUIRED CSS: BOOTSTRAP, FONTAWESOME, PERFECT-SCROLLBAR  -->
    <link rel="stylesheet" href="../dist/css/vendor.min.css">


    <!-- Mimity CSS  -->
    <link rel="stylesheet" href="../dist/css/style.min.css">


    <title>Wishlist | <?php echo e(config('app.name')); ?></title>
  </head>
<?php $__env->stopSection(); ?>  
  
<?php $__env->startSection('main-content'); ?>

        <div class="col" id="main-content">
          <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <div class="card user-card">
            <div class="card-body">
              <div class="media">
                <?php echo $__env->make('inc.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <hr>
              <?php if(Cart::instance('wishlist')->count()): ?>
              <table class="table table-cart">
                <tbody>
                  
                  <?php $__currentLoopData = Cart::instance('wishlist')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td>                      
                      
                    </td>
                    <td>
                      <a href="<?php echo e(route('shop.show', $item->model->slug)); ?>"><img src="<?php echo e(productImage($item->model->image)); ?>" width="50" height="50" alt="<?php echo e($item->model->name); ?> - <?php echo $item->model->details; ?>"></a>         
                      <form action="<?php echo e(route('wishlist.destroy', $item->rowId)); ?>" method="POST">
                          <?php echo e(csrf_field()); ?>

                          <?php echo e(method_field('DELETE')); ?>

                          <button type="submit" class="btn btn-sm btn-outline-warning rounded">Remove</button>
                      </form>
                    </td>
                    <td>
                      <h6><a href="<?php echo e(route('shop.show', $item->model->slug)); ?>" class="text-body"><?php echo e($item->model->name); ?> - <?php echo $item->model->details; ?></a></h6>
                      <h6 class="text-muted">&#8358;<?php echo e(number_format( totalcash($item->model->price, $item->model->profit) )); ?></h6>
                      
                        <?php echo getStockLevel($item->model->quantity); ?>

                      
                    </td>
                    <td>
                      <form action="<?php echo e(route('wishlist.switchToCart', $item->rowId)); ?>" method="POST">
                          <?php echo e(csrf_field()); ?>

                        <button type="submit" class="btn btn-info btn-sm">Move to cart</button>
                      </form>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  
                  
                </tbody>
              </table>
              <?php endif; ?>
            </div>
          </div>


        <?php $__env->stopSection(); ?>



<?php $__env->startSection('required-js'); ?>
    <!-- REQUIRED JS  -->
    <script src="../plugins/jquery/jquery.min.js"></script>
    <script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>


    <!-- Mimity JS  -->
    <script src="../dist/js/script.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ziksdxfh/ziksales/resources/views/account-wishlist.blade.php ENDPATH**/ ?>