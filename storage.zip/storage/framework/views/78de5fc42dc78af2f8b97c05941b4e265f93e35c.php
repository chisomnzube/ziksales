<?php
  use App\Category;
  $categories = Category::all();
?>

<?php $__env->startSection('head'); ?>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- FONT  -->
    <!-- <link rel="stylesheet" href="../fonts/fira-sans.css"> -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Fira+Sans">

    <!-- REQUIRED CSS: BOOTSTRAP, FONTAWESOME, PERFECT-SCROLLBAR  -->
    <link rel="stylesheet" href="../dist/css/vendor.min.css">


    <!-- Mimity CSS  -->
    <link rel="stylesheet" href="../dist/css/style.min.css">


    <title>Branding - Seller's Portal | <?php echo e(config('app.name')); ?></title>
    <script type="text/javascript">
      function closedic()
        {
          document.getElementById('read').style.display = "none";
        }
    </script>
    <style type="text/css">
      #read{
        background-color: lightblue;
        border-radius: 4px;
      }
    </style>
  </head>
<?php $__env->stopSection(); ?>  
  
<?php $__env->startSection('main-content'); ?>

        <div class="col" id="main-content">
          <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <div class="row justify-content-center">
            <div class="col-xl-6 col-md-8 col-12">
              
              
              <div class="btn-group" role="group" aria-label="Basic example">
                <a class="btn btn-outline-info" href="<?php echo e(route('users.edit')); ?>">Profile</a>&nbsp;
                <a class="btn btn-outline-info" href="<?php echo e(route('orders.index')); ?>">Order</a>&nbsp;
                <a class="btn btn-outline-info" href="<?php echo e(route('wishlist.index')); ?>">Wishlist</a>&nbsp;
                <a class="btn btn-outline-info" href="<?php echo e(route('seller.brand')); ?>">Branding</a>
              </div> 
              <br><br>
              <div class="tab-content">
                <div class="tab-pane fade show active" id="login" role="tabpanel" aria-labelledby="login-tab">
                  <div class="card shadow-sm">

                    <?php if(checkBranding(auth()->user()->id) < 1): ?>
                    <div class="card-body">
                      <form method="POST" action="<?php echo e(route('brand.store')); ?>" aria-label="Brand's Registration">
                          <?php echo csrf_field(); ?>
                          <?php echo app('captcha')->render(); ?>
                        <div class="form-row">
                          
                          
                          
                          <div class="form-group col-sm-12">
                          	<p><b>Note: This brand name is unique to you</b></p>
                          </div>
                          <div class="form-group col-sm-12">
                             <input type="text"  class="form-control" placeholder="Brand Name" id="registerphone" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
                          </div>
                         
                          <div class="form-group col-12">
                            <button type="submit" class="btn btn-success btn-block">Submit</button>
                          </div>
                        </div>
                      </form>
                      
                    </div>
                    <?php else: ?>
                    <div class="card-body">
                      <strong>Your link is: 
                        <a href="<?php echo e(route('brand.name', getBrandName(auth()->user()->id)->slug)); ?>"><?php echo e(route('brand.name', getBrandName(auth()->user()->id)->slug)); ?></a>
                      </strong>
                      <hr>
                      <div class="d-flex align-items-center">
                        <span class="text-muted">Share</span>
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(route('brand.name', getBrandName(auth()->user()->id)->slug)); ?>" class="btn btn-light btn-icon rounded-circle border ml-2" data-toggle="tooltip" title="Facebook" target="_blank"><i data-feather="facebook" class="fa fa-facebook"></i></a>
                        <a href="https://twitter.com/intent/tweet?text=Check out my products on ziksales, click the link <?php echo e(route('brand.name', getBrandName(auth()->user()->id)->slug)); ?>" class="btn btn-light btn-icon rounded-circle border ml-2" data-toggle="tooltip" title="Twitter"><i data-feather="twitter" class="fa fa-twitter" target="_blank"></i></a>
                        <a href="https://wa.me/?text=Check out my products on ziksales, click the link <?php echo e(route('brand.name', getBrandName(auth()->user()->id)->slug)); ?>" class="btn btn-light btn-icon rounded-circle border ml-2" data-toggle="tooltip" title="Whatsapp" target="_blank"><i data-feather="whatsapp" class="fa fa-whatsapp"></i></a>
                      </div>
                      <hr>
                      <form method="POST" action="<?php echo e(route('brand.update')); ?>" aria-label="Brand's Registration">
                          <?php echo csrf_field(); ?>
                          <?php echo app('captcha')->render(); ?>
                        <div class="form-row">
                          
                          
                          
                          <div class="form-group col-sm-12">
                            <p><b>Note: This brand name is unique to you</b></p>
                          </div>
                          <div class="form-group col-sm-12">
                             <input type="text"  class="form-control" placeholder="Brand Name" id="registerphone" name="name"         value="<?php echo e(getBrandName(auth()->user()->id)->name); ?>" required autofocus>
                          </div>
                         
                          <div class="form-group col-12">
                            <button type="submit" class="btn btn-success btn-block">Update</button>
                          </div>
                        </div>
                      </form>
                      
                    </div>
                    <?php endif; ?>

                  </div>
                </div>
                
              </div>
            </div>
          </div>

        </div>

        <?php $__env->stopSection(); ?>
      
<?php $__env->startSection('required-js'); ?>

    <!-- REQUIRED JS  -->
    <script src="../plugins/jquery/jquery.min.js"></script>
    <script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>


    <!-- Mimity JS  -->
    <script src="../dist/js/script.min.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ziksdxfh/ziksales/resources/views/seller-brand.blade.php ENDPATH**/ ?>