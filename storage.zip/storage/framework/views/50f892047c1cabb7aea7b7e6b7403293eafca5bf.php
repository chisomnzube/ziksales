<?php $__env->startSection('head'); ?>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="Ziksales, Best E-commerce Site In Nigeria, I want to Buy, about Phones and Tablets, Men's fashion, Women's fashion, Electronics, Health and Beauty, Computing, Grocery, Sporting Goods, Home and Kitchen. ">
    <meta name="description" content="My Checkout Page. Ziksales is an excellent E-commerce platform that makes buying and selling easy. We give you a safe, comfortable, secure and excellent shopping experience. We deal on products like Phones and Tablets, Men's fashion, Women's fashion, Electronics, Health and Beauty, Computing, Grocery, Sporting Goods, Home and Kitchen. Feel free shopping with us.">

    <!-- FONT  -->
    <!-- <link rel="stylesheet" href="../fonts/fira-sans.css"> -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Fira+Sans">

    <!-- REQUIRED CSS: BOOTSTRAP, FONTAWESOME, PERFECT-SCROLLBAR  -->
    <link rel="stylesheet" href="../dist/css/vendor.min.css">


    <!-- Mimity CSS  -->
    <link rel="stylesheet" href="../dist/css/style.min.css">


    <title>Checkout | <?php echo e(config('app.name')); ?></title>
  </head>
<?php $__env->stopSection(); ?>  
  
<?php
  foreach(Cart::instance('default')->content() as $item)
    {
        $product_id[] = $item->model->id;
        $product_qty[] = $item->qty;
    }
?>

<?php $__env->startSection('main-content'); ?>
        <div class="col" id="main-content">
          <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <div class="row">
            <div class="col-sm-7 col-md-8">
              <h3 class="title"><i class="fa fa-map-marker"></i> Delivery address</h3>
              
              <hr>
              <form class="bg-light p-3 border shadow-sm" method="POST" action="<?php echo e(route('pay')); ?>" accept-charset="UTF-8" class="form-horizontal" role="form">
                <div class="form-group">
                  <label for="checkoutName">Name</label>
                  <input type="text" name="name" class="form-control" id="checkoutName" value="<?php echo e(auth()->user()->name.' '. auth()->user()->lname); ?>" disabled>
                </div>
                <div class="form-group">
                  <label for="checkoutPhone">Phone</label>
                  <input type="text" name="phone" class="form-control" id="checkoutPhone" value="<?php echo e(auth()->user()->phone); ?>" disabled>
                </div>
                <div class="form-group">
                  <label for="checkoutAddr1">Profile Delivery Address</label>
                  <input name="address" type="text" class="form-control" id="checkoutAddr1" value="<?php echo e(auth()->user()->address); ?>" disabled>
                </div>
                <div class="form-group">
                  <label for="checkoutAddr1">Delivery Address (Leave blank if you want to use your profile delivery address.)</label>
                  <input name="altaddress" type="text" class="form-control" id="altaddress" value="">
                  <small id="addr2Help" class="form-text text-muted">* Leave blank if you want delivery at your profile address </small>
                </div>
                
                    <input type="hidden" name="email" value="<?php echo e(auth()->user()->email); ?>"> 
                    
                    <input type="hidden"  name="amount" value="<?php echo e($newTotal); ?>00"> 
                    <input type="hidden" name="quantity" value="1">
                    <input type="hidden" id="metadata" name="metadata" value="<?php echo e(json_encode($array = ['name' => auth()->user()->name,'address' => auth()->user()->address, 'phone' => auth()->user()->phone, 'delivery_fee' => $delivery_sum, 'user_id' => auth()->user()->id, 'newSubtotal' => $newSubtotal, 'discount' => $discount, 'discount_code' => $discount_code, 'product_id' => $product_id, 'product_qty' => $product_qty, 'altaddress' =>  '', ])); ?>" > 
                    <input type="hidden" name="reference" value="<?php echo e(Paystack::genTranxRef()); ?>"> 
                    <input type="hidden" name="key" value="<?php echo e(config('paystack.secretKey')); ?>"> 
                    <?php echo e(csrf_field()); ?> 

                    <div class="btn-group btn-group-justified">
                      <p>
                        
                      </p>&nbsp;
                      <p>                        
                        <a class="btn btn-info btn-lg btn-block" href='tel:+2348140987860'><i class="fa fa-phone fa-lg"></i> Call To Order</a>
                      </p>
                    </div>
              </form>
              
             
            </div>
            <div class="col-sm-5 col-md-4 pt-5">
              <h4 class="title mb-3">Order summary</h4>
              
              <?php if(Cart::content()->count() > 0): ?>
                <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="media border-bottom mb-3">
                  <img src="<?php echo e(productImage($item->model->image)); ?>" width="50" height="50" alt="<?php echo e($item->model->name); ?> - <?php echo str_limit($item->model->details, 30); ?>">
                  <div class="media-body ml-3">
                    <h6><?php echo e($item->model->name); ?> - <?php echo str_limit($item->model->details, 30); ?></h6>
                    <div><?php echo e($item->qty); ?> x <span class="price">&#8358;<?php echo e(number_format( totalcash($item->model->price, $item->model->profit) )); ?></span></div>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
              
              
              <div class="d-flex justify-content-between">
                <span>Sub Total</span>
                <span>&#8358;<?php echo e(number_format(Cart::subtotal())); ?></span>
              </div>
              <?php if(session()->has('coupon')): ?>
                <div class="d-flex justify-content-between">
                  <span>Discount(<?php echo e(session()->get('coupon')['name']); ?>)</span>
                  <span>- &#8358;<?php echo e(number_format($discount)); ?></span>
                </div>
               
              <div class="d-flex justify-content-between">
                <span>New SubTotal</span>
                <span> &#8358;<?php echo e(number_format($newSubtotal)); ?></span>
              </div>
              <?php endif; ?> 

              <div class="d-flex justify-content-between">
                <span>Delivery Fee</span>
                <span>&#8358;<?php echo e(number_format($delivery_sum)); ?></span>
              </div>
              <hr>
              <div class="box-total">
                  <h4>TOTAL</h4>
                  <h4><span class="price">&#8358;<?php echo e(number_format($newTotal)); ?></span></h4>
              </div>              

            </div>
          </div>

        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        <?php $__env->stopSection(); ?>


<?php $__env->startSection('required-js'); ?>
    <script>
      function alty() 
        {
          var altaddress = document.getElementById('altaddress').value;
          var metadata = document.getElementById('metadata').value;
          var position = -2;
          var output = [metadata.slice(0, position), altaddress, metadata.slice(position)].join('');
          document.getElementById('metadata').value = output;
          //window.alert(output);
          //document.getElementById('demoalt').innerHTML = altaddress;
          //document.getElementById('demoamount').value = altaddress;
        }
    </script>
    <!-- REQUIRED JS  -->
    <script src="../plugins/jquery/jquery.min.js"></script>
    <script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>


    <!-- Mimity JS  -->
    <script src="../dist/js/script.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ziksdxfh/ziksales/resources/views/checkout.blade.php ENDPATH**/ ?>