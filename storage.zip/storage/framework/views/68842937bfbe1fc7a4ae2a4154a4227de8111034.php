              <?php if(auth()->guard()->check()): ?>
                <img src="../img/user.png" class="img-thumbnail rounded-circle" alt="John Thor">
                <div class="media-body ml-3 pt-4">
                  <h4><?php echo e($user->name." ".$user->lname); ?></h4>
                  <div class="small text-muted">Joined <?php echo e($user->created_at); ?></div>
                  
                  
                </div>
              </div>
              <hr>
              <ul class="nav nav-pills">
                <li class="nav-item">
                  <a class="nav-link <?php echo e(url()->current() == 'https://ziksales.com/my-profile' ? 'active' : ''); ?>" href="<?php echo e(route('users.edit')); ?>">Profile</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link <?php echo e(url()->current() == 'https://ziksales.com/my-orders' ? 'active' : ''); ?>" href="<?php echo e(route('orders.index')); ?>">Orders</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link <?php echo e(url()->current() == 'https://ziksales.com/wishlist' ? 'active' : ''); ?>" href="<?php echo e(route('wishlist.index')); ?>">Wishlist</a>
                </li>
                <?php if($seller->email != auth()->user()->email): ?>                  
                  <li class="nav-item">
                    <a class="nav-link " href="<?php echo e(route('seller.register')); ?>">Become a seller</a>
                  </li>
                <?php else: ?>
                  <?php if($seller->featured != true): ?>
                    <li class="nav-item">
                      <a class="nav-link" >Seller's Account Awaiting Approval</a>
                    </li>
                  <?php else: ?>
                      <li class="nav-item">
                        <a class="nav-link " href="<?php echo e(route('seller.index')); ?>">Seller's Portal</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link " href="<?php echo e(route('seller.brand')); ?>">Branding</a>
                      </li>
                  <?php endif; ?>  
                <?php endif; ?> 
              </ul>
                <?php endif; ?><?php /**PATH /home/ziksdxfh/ziksales/resources/views/inc/account.blade.php ENDPATH**/ ?>