<?php $__env->startSection('head'); ?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="<?php echo str_limit($post->meta_keywords, 60); ?>">
    <meta name="description" content="<?php echo str_limit($post->body, 150); ?>">
  

    <!-- FONTS  -->
    <!-- <link rel="stylesheet" href="../fonts/nunito.css"> -->
    <!-- <link rel="stylesheet" href="../fonts/roboto.css"> -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700">

    <!-- REQUIRED CSS: BOOTSTRAP, METISMENU, PERFECT-SCROLLBAR  -->
    <link rel="stylesheet" href="../dist/css/vendor.min.css">


    <!-- Mimity CSS  -->
    <link rel="stylesheet" href="../dist/css/style.min.css">

    <title><?php echo $post->title; ?> | <?php echo e(config('app.name')); ?></title>
  </head>
<?php $__env->stopSection(); ?>  

<?php $__env->startSection('main-content'); ?>
    <!-- Main Content -->
    <div class="container my-3">
      <div class="row">

        <div class="col">
        <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="card">
            <div class="card-body" lang="zxx"> <!-- because 'lorem ipsum' is not english language, so we add lang="zxx" attribute, remove it on production environment -->

              <!-- Blog Info -->
              <ul class="list-inline">
                <li class="list-inline-item"><small><i data-feather="clock"></i><?php echo e($post->created_at); ?></small></li>
                <li class="list-inline-item"><small><i data-feather="user"></i> <a href="javascript:void(0)" class="text-muted">Admin</a></small></li>
                
              </ul>

              <!-- Blog Content -->
              <h2 class="bold"><?php echo $post->title; ?></h2>
              <img src="<?php echo e(productImage($post->image)); ?>" alt="<?php echo $post->title; ?>" class="img-fluid my-3">
              <p><?php echo $post->body; ?></p>

              <!-- /Blog Content -->

              <!-- Share Button -->
              <div class="d-flex align-items-center">
                <span class="text-muted">Share post: </span>
                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url()->current()); ?>" class="btn btn-light btn-icon rounded-circle border ml-2" data-toggle="tooltip" title="Facebook" target="_blank"><i data-feather="facebook" class="fa fa-facebook"></i></a>
                <a href="https://twitter.com/intent/tweet?text=Check Out <?php echo e($post->title.' '.str_limit($post->excerpt, 100).' - Click on the link '); ?><?php echo e(url()->current()); ?>" class="btn btn-light btn-icon rounded-circle border ml-2" data-toggle="tooltip" title="Twitter"><i data-feather="twitter" class="fa fa-twitter" target="_blank"></i></a>
                <a href="https://wa.me/?text=Check Out <?php echo e($post->title.' '.str_limit($post->excerpt, 100).' - Click on the link '); ?><?php echo e(url()->current()); ?>" class="btn btn-light btn-icon rounded-circle border ml-2" data-toggle="tooltip" title="Whatsapp" target="_blank"><i data-feather="whatsapp" class="fa fa-whatsapp"></i></a>
              </div>
              <!-- /Share Button -->

              <hr>

              <!-- Blog Comments -->
              <h3>Comments</h3>
              <?php if(auth()->guard()->check()): ?>
              <div class="media my-4">
                <div class="media-body ml-2 ml-sm-3">
                  <form action="<?php echo e(route('blog.store')); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <textarea name="body" rows="2" placeholder="Leave a comment" class="form-control border autosize"></textarea>
                    <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                  <button type="submit" class="btn btn-sm btn-success border border-top-0 btn-block">Post</button>
                  </form>
                </div>
              </div>
              <?php endif; ?>

              <?php if($comments->count() > 0): ?>
              <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="media">
                <a href="javascript:void(0)"><img src="../img/user.svg" alt="User" width="45" height="45" class="rounded-circle"></a>
                <div class="media-body ml-2 ml-sm-3">
                  <div class="d-flex flex-wrap">
                    <a href="javascript:void(0)" class="mr-2"><?php echo e($comment->name); ?></a>
                    <span class="text-muted"><?php echo e($comment->created_at); ?></span>
                  </div>
                  <p><?php echo e($comment->body); ?></p>
                  <ul class="list-inline">
                    <li class="list-inline-item"><a href="javascript:void(0)" class="text-muted" title="vote up"><i data-feather="chevron-up"></i></a></li>
                    <li class="list-inline-item"><a href="javascript:void(0)" class="text-muted" title="vote down"><i data-feather="chevron-down"></i></a></li>
                    
                  </ul>
                  <hr>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
              <p>No Comment yet!</p>
              <?php endif; ?>
              <!-- /Blog Comments -->

            </div>
          </div>
        </div>

        <!-- Blog Sidebar -->
        <div class="col-md-4 col-lg-4 mt-3 mt-md-0">
          <div class="card">
            <div class="card-header bg-white border-bottom bold roboto-condensed">
              <h5 class="bold mb-0">POPULAR THIS <span class="text-primary">WEEK</span></h5>
            </div>
            <div class="card-body">

              <div class="row">
                
                <?php if($populars->count() > 0): ?>
                <?php $__currentLoopData = $populars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-sm-6 col-md-12">
                  <div class="card card-blog shadow-none">
                    <a href="<?php echo e(route('blog.show', $popular->slug)); ?>" class="zoom-hover"><img style="width: 100%; height: 100%;" src="<?php echo e(productImage($popular->image)); ?>" alt="<?php echo $popular->title; ?>"></a>
                    <div class="card-body p-0 text-center">
                      <a href="<?php echo e(route('blog.show', $popular->slug)); ?>" class="title h5 mt-3"><?php echo $popular->title; ?></a>
                      <div class="small text-muted">
                        <i data-feather="message-square" class="ml-3"></i> <?php echo e(countComment($popular->id)); ?> Comments
                      </div>
                    </div>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <p>No Popular Post this week</p>
                <?php endif; ?>
              </div>

            </div>
          </div>

          <div class="card mt-3">
            <div class="card-header bg-white border-bottom bold roboto-condensed">
              <h5 class="bold mb-0">POST <span class="text-primary">TAGS</span></h5>
            </div>
            <div class="card-body">
              <div class="btn-group-scatter">
                <?php if(!empty($post->meta_keywords)): ?>
                  <?php $keywords = explode(',', $post->meta_keywords) ?>
                  <?php $__currentLoopData = $keywords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="javascript:void(0)" class="btn btn-light rounded-pill"><?php echo e($keyword); ?></a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                <?php endif; ?>

              </div>
            </div>
          </div>
        </div>
        <!-- /Blog Sidebar -->

      </div>
    </div>
    <!-- /Main Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('required-js'); ?>
    <!-- REQUIRED JS  -->
    <script src="../plugins/jquery/jquery.min.js"></script>
    <script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../plugins/feather-icons/feather.min.js"></script>
    <script src="../plugins/metismenu/metisMenu.min.js"></script>
    <script src="../plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>

    <!-- PLUGINS FOR CURRENT PAGE -->
    <script src="../plugins/autosize/autosize.min.js"></script>

    <!-- Mimity JS  -->
    <script src="../dist/js/script.min.js"></script>

    <script>
    $(function () {

      // Autosize textarea
      autosize($('textarea.autosize'))

    })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ziksdxfh/ziksales/resources/views/blog-single.blade.php ENDPATH**/ ?>