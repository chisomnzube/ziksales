        <!-- Footer -->
          <div class="navbar navbar-expand navbar-light navbar-footer">
            <img style="width:100px; height:50px;" src="<?php echo e(asset('../img/blog/comodo.png')); ?>">
            
            <ul class="navbar-nav">
              <li class="nav-item">
                
                <span><a style="display: inline;" class="nav-link" href="https://api.whatsapp.com/send?phone=+2347031382795"><i class="fa fa-whatsapp fa-lg"></i> Let's Chat</a></span>
              </li>
              <li class="nav-item"><a style="color: black;" href="<?php echo e(route('tandc')); ?>">Terms and conditions</a></li> | 
              <li class="nav-item"><a style="color: black;" href="<?php echo e(route('policy')); ?>">Privacy Policy</a></li>
            </ul>

          </div>
          <!-- /Footer --><?php /**PATH /home/ziksdxfh/ziksales/resources/views/layouts/footer.blade.php ENDPATH**/ ?>