<?php
  use App\Category;
  $categories = Category::all();
?>

<?php $__env->startSection('head'); ?>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- FONT  -->
    <!-- <link rel="stylesheet" href="../fonts/fira-sans.css"> -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Fira+Sans">

    <!-- REQUIRED CSS: BOOTSTRAP, FONTAWESOME, PERFECT-SCROLLBAR  -->
    <link rel="stylesheet" href="../dist/css/vendor.min.css">


    <!-- Mimity CSS  -->
    <link rel="stylesheet" href="../dist/css/style.min.css">


    <title>Ziksales - Register</title>
  </head>
<?php $__env->stopSection(); ?>  
  
<?php $__env->startSection('main-content'); ?>

        <div class="col" id="main-content">
          <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <div class="row justify-content-center">
            <div class="col-xl-6 col-md-8 col-12">
              <nav class="d-flex justify-content-center mb-4">
                <div class="btn-group nav" role="tablist">
                  
                  <a class="btn btn-outline-info" data-toggle="tab"  id="register-tab" role="tab" aria-controls="register" aria-selected="false">Register</a>
                </div>
              </nav>
              <div class="tab-content">
                <div class="tab-pane fade show active" id="login" role="tabpanel" aria-labelledby="login-tab">
                  <div class="card shadow-sm">
                    <div class="card-body">
                      <form method="POST" action="<?php echo e(route('register')); ?>" aria-label="<?php echo e(__('Register')); ?>">
                          <?php echo csrf_field(); ?>
                          <?php echo app('captcha')->render(); ?>
    			            <?php if(count($errors) > 0): ?>
    			                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    			                    <?php echo e($error); ?>

    			                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    			            <?php endif; ?>
                        <div class="form-row">
                          <div class="form-group col-sm-6">
                            <label for="registerFirstName">First Name</label>
                            <input type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" id="registerFirstName" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                          </div>
                          <div class="form-group col-sm-6">
                            <label for="registerFirstName">Last Name</label>
                            <input type="text"  class="form-control<?php echo e($errors->has('lname') ? ' is-invalid' : ''); ?>" id="registerFirstName" name="lname" value="<?php echo e(old('lname')); ?>" required autofocus>
                                <?php if($errors->has('lname')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('lname')); ?></strong>
                                    </span>
                                <?php endif; ?>
                          </div>
                          
                          <div class="form-group col-sm-6">
                            <label for="registerEmail">Email address</label>
                            <input type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" id="registerEmail" name="email" value="<?php echo e(old('email')); ?>" required>
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                          </div>
                          <div class="form-group col-sm-6">
                            <label for="registerPhone">Phone Number</label>
                             <input type="text"  class="form-control<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" id="registerphone" name="phone" value="<?php echo e(old('phone')); ?>" required autofocus>
                                <?php if($errors->has('phone')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('phone')); ?></strong>
                                    </span>
                                <?php endif; ?>
                          </div>
                          <div class="form-group col-sm-6">
                            <label for="registerPassword">Password</label>
                            <input type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" id="registerPassword" name="password" required>
                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                          </div>
                          <div class="form-group col-sm-6">
                            <label for="registerConfirmPassword">Confirm Password</label>
                            <input type="password" class="form-control" id="registerConfirmPassword" name="password_confirmation" required>
                          </div>
                          <div class="form-group col-sm-12">
                            <label for="registerLastName">Address</label>
                             <input type="text"  class="form-control<?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>" id="registeraddress" name="address" value="<?php echo e(old('address')); ?>" required autofocus>
                                <?php if($errors->has('address')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('address')); ?></strong>
                                    </span>
                                <?php endif; ?>
                          </div>
                          <input type="hidden" name="referrer" value="<?php echo e(session()->get('refId') ? session()->get('refId') : 'NoRef'); ?>">
                          <div class="form-group col-12">
                            <button type="submit" class="btn btn-success btn-block">REGISTER</button>
                          </div>
                        </div>
                      </form>
                      <p>Already registered? click <a href="/login">Here</a> to Login</p>
                    </div>
                  </div>
                </div>
                
              </div>
            </div>
          </div>

        </div>

        <?php $__env->stopSection(); ?>
      
<?php $__env->startSection('required-js'); ?>

    <!-- REQUIRED JS  -->
    <script src="../plugins/jquery/jquery.min.js"></script>
    <script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>


    <!-- Mimity JS  -->
    <script src="../dist/js/script.min.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ziksdxfh/ziksales/resources/views/auth/register.blade.php ENDPATH**/ ?>