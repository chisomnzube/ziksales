<?php $__env->startSection('head'); ?>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="Ziksales, Best E-commerce Site In Nigeria, I want to Buy, about Phones and Tablets, Men's fashion, Women's fashion, Electronics, Health and Beauty, Computing, Grocery, Sporting Goods, Home and Kitchen.">
    <meta name="description" content="<?php echo e(request()->input('item')); ?>. Ziksales is an excellent E-commerce platform that makes buying and selling easy. We give you a safe, comfortable, secure and excellent shopping experience. We deal on products like Phones and Tablets, Men's fashion, Women's fashion, Electronics, Health and Beauty, Computing, Grocery, Sporting Goods, Home and Kitchen. Feel free shopping with us.">

    <!-- FONT  -->
    <!-- <link rel="stylesheet" href="../fonts/fira-sans.css"> -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Fira+Sans">

    <!-- REQUIRED CSS: BOOTSTRAP, FONTAWESOME, PERFECT-SCROLLBAR  -->
    <link rel="stylesheet" href="../dist/css/vendor.min.css">


    <!-- PLUGINS FOR CURRENT PAGE -->
    <link rel="stylesheet" href="../plugins/nouislider/nouislider.min.css">

    <!-- Mimity CSS  -->
    <link rel="stylesheet" href="../dist/css/style.min.css">


    <title><?php echo e(request()->input('item')); ?> - Search | <?php echo e(config('app.name')); ?></title>
    <style>
        /*width:100%;*/
        @media (max-width: 720px) {
            .dimg {
                height: 135px;
            }
        }
        @media (min-width: 730px) {
            .dimg {
                height: 250px;
            }
        }
    </style>
  </head>
  <?php $__env->stopSection(); ?>
  

<?php $__env->startSection('main-content'); ?>
        <div class="col" id="main-content">
          <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


          <div class="d-flex justify-content-between">
            <!-- Tags -->
            <div class="btn-tags">
              <?php if($categories->count() > 0): ?>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <a href="<?php echo e(route('shop.index',['category' => $category->slug,])); ?>" class="btn btn-light btn-sm  <?php echo e(request()->category == $category->slug ? 'active' : ''); ?>"><?php echo $category->name; ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>

            </div>
            <!-- /Tags -->

            <!-- Filter Modal Toggler -->
            <span>
              <button class="btn btn-outline-info btn-sm" data-toggle="modal" data-target="#filterModal"><i class="fa fa-filter"></i> FILTER</button>
            </span>
          </div>

          <!-- Grid -->
          <div class="d-flex justify-content-between mt-4">
            <h3 class="title"> <?php echo e($products->total()); ?> search result(s) for <?php echo e(request()->input('item')); ?> </h3>
            <div class="btn-group btn-group-sm align-self-start" role="group">
            </div>
          </div>
          <div class="row no-gutters gutters-2">

            <?php if($products->count() > 0): ?>
              <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-6 col-md-3 mb-2">
                    <div class="card card-product" style="height: 100%; width: 100%;">
                      <?php echo $product->quantity < setting('site.stock_threshold') ? '<div class="badge badge-danger badge-pill">Only '.$product->quantity.' left</div>' : ''; ?>

                      <a href="<?php echo e(route('shop.show', $product->slug)); ?>"><img src="<?php echo e(productImage($product->image)); ?>" alt="<?php echo e($product->name); ?> - <?php echo str_limit($product->details, 30); ?>" class="card-img-top dimg"></a>
                      <div class="card-body">
                        <span class="price"><del class="small text-muted">&#8358;<?php echo e(number_format( slash($product->price, $product->profit) )); ?></del>&#8358;<?php echo e(number_format( totalcash($product->price, $product->profit) )); ?></span>
                        <a href="<?php echo e(route('shop.show', $product->slug)); ?>" class="card-title h6"><small><?php echo e($product->name); ?> - <?php echo str_limit($product->details, 30); ?></small></a>

                      </div>
                    </div>
                  </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <p>No product Found</p>
            <?php endif; ?>         

          </div>
          <!-- /Grid -->

          <!-- Pagination -->
          <nav aria-label="Page navigation Shop Grid">
            <div class="pagination justify-content-center">
              
              <?php echo e($products->appends(request()->input())->onEachSide(1)->links()); ?> 
            </div>         
            
          </nav>
          <!-- /Pagination -->

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>          
<?php $__env->stopSection(); ?>        
      

    <!-- Modal Cart -->


    <!-- Modal filter -->
    <div class="modal fade modal-filter" id="filterModal" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-body">
            <div class="form-group">
                <label for="filterSortBy">By Price</label><br>
                <a href="<?php echo e(route('search', ['item' => request()->input('item'), 'sort' => 'low_high'])); ?>">Low to High</a><br>
                <a href="<?php echo e(route('search', ['item' => request()->input('item'), 'sort' => 'high_low'])); ?>">High to Low</a>
            </div>
            
          </div>
        </div>
      </div>
    </div>

<?php $__env->startSection('required-js'); ?>
    <!-- REQUIRED JS  -->
    <script src="../plugins/jquery/jquery.min.js"></script>
    <script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>


    <!-- PLUGINS FOR CURRENT PAGE -->
    <script src="../plugins/nouislider/nouislider.min.js"></script>
    <script src="../plugins/raty-fa/jquery.raty-fa.min.js"></script>

    <!-- Mimity JS  -->
    <script src="../dist/js/script.min.js"></script>
<?php $__env->stopSection(); ?>    

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ziksdxfh/ziksales/resources/views/search-results.blade.php ENDPATH**/ ?>