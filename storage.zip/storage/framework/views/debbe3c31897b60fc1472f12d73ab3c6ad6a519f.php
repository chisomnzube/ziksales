<?php $__env->startSection('head'); ?>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="Ziksales Cart, Best E-commerce Site In Nigeria, I want to Buy, about Phones and Tablets, Men's fashion, Women's fashion, Electronics, Health and Beauty, Computing, Grocery, Sporting Goods, Home and Kitchen. ">
    <meta name="description" content="My cart - Ziksales. Ziksales is an excellent E-commerce platform that makes buying and selling easy. We give you a safe, comfortable, secure and excellent shopping experience. We deal on products like Phones and Tablets, Men's fashion, Women's fashion, Electronics, Health and Beauty, Computing, Grocery, Sporting Goods, Home and Kitchen. Feel free shopping with us.">

    <!-- FONT  -->
    <!-- <link rel="stylesheet" href="../fonts/fira-sans.css"> -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Fira+Sans">

    <!-- REQUIRED CSS: BOOTSTRAP, FONTAWESOME, PERFECT-SCROLLBAR  -->
    <link rel="stylesheet" href="../dist/css/vendor.min.css">


    <!-- PLUGINS FOR CURRENT PAGE -->
    <link rel="stylesheet" href="../plugins/swiper/swiper.min.css ">

    <!-- Mimity CSS  -->
    <link rel="stylesheet" href="../dist/css/style.min.css ">


    <title>My Cart | <?php echo e(config('app.name')); ?></title>
    <style>
        /*width:100%;*/
        @media (max-width: 720px) {
            .dimg {
                height: 120px;
            }
        }
        @media (min-width: 730px) {
            .dimg {
                height: 250px;
            }
        }
    </style>
  </head>
<?php $__env->stopSection(); ?>  
        
<?php $__env->startSection('main-content'); ?>


        <div class="col" id="main-content">
          <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <?php if(Cart::count() > 0): ?>
          <h3 class="title mb-3">You have <?php echo e(Cart::count()); ?> item(s) in your cart</h3>

          <!-- Shopping Cart Table -->
          <table class="table table-cart">
            <tbody>
              
              <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>                  
                  <form action="<?php echo e(route('cart.destroy', $item->rowId)); ?>" method="POST">
                      <?php echo e(csrf_field()); ?>

                      <?php echo e(method_field('DELETE')); ?>

                      <button type="submit" class="btn btn-sm btn-outline-warning rounded-circle" title="Remove"><i class="fa fa-close"></i></button>
                  </form>
                </td>
                <td>
                  <a href="<?php echo e(route('shop.show', $item->model->slug)); ?>"><img src="<?php echo e(productImage($item->model->image)); ?>" width="50" height="50" alt="<?php echo e($item->model->name); ?> - <?php echo str_limit($item->model->details, 30); ?>"></a>                  
                  <form action="<?php echo e(route('cart.destroy', $item->rowId)); ?>" method="POST">
                      <?php echo e(csrf_field()); ?>

                      <?php echo e(method_field('DELETE')); ?>

                      <button type="submit" class="btn btn-sm btn-outline-warning rounded">Remove</button>
                  </form>
                </td>
                <td>
                  <h6><a href="<?php echo e(route('shop.show', $item->model->slug)); ?>" class="text-body"><?php echo e($item->model->name); ?> - <?php echo str_limit($item->model->details, 30); ?></a></h6>
                  <h6 class="text-muted">&#8358;<?php echo e(number_format( $item->subtotal)); ?></h6>
                  
                  
                  <form action="<?php echo e(route('cart.wishlist', $item->rowId)); ?>" method="POST">
                      <?php echo e(csrf_field()); ?>

                      <button type="submit" class="btn btn-primary btn-sm">Add to wishlist</button>
                  </form>
                  
                </td>
                <td>
                  <div class="input-spinner">
                    

                    <select class="quantity form-control" data-id="<?php echo e($item->rowId); ?>" data-productQuantity="<?php echo e($item->model->quantity); ?>">
                        <?php for($i = 1; $i < 5 + 1; $i++): ?>
                            <option <?php echo e($item->qty == $i ? 'selected' : ''); ?> ><?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                  </div>
                  
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     


              <tr>
                <td colspan="4">
                  <div class="box-total">
                    <h4>Total: <span class="price">&#8358;<?php echo e(number_format($newTotal)); ?></span></h4>
                    <a href="<?php echo e(route('checkout.index')); ?>" class="btn btn-success">CHECKOUT</a>
                  </div>
                </td>
              </tr>

            </tbody>
          </table>

            <?php if(! session()->has('coupon')): ?>
              <tr>
                <td colspan="12">
                      <form class="bg-light p-3 border shadow-sm" method="POST" action="<?php echo e(route('coupon.store')); ?>" accept-charset="UTF-8" class="form-horizontal" role="form">
                      <?php echo e(csrf_field()); ?>

                        <label for="checkoutName">Have Coupon Code?</label>
                          <input type="text" name="coupon_code" class="form-control" id="coupon_code">
                          
                          <button type="submit" class="btn btn-primary">Apply</button>
                    </form>
                </td>
              </tr>

              <?php else: ?>
              <tr>
                <td colspan="12">
                <form class="bg-light p-3 border shadow-sm" method="POST" action="<?php echo e(route('coupon.destroy')); ?>" accept-charset="UTF-8" class="form-horizontal" role="form">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('delete')); ?>

                    <button type="submit" class="btn btn-primary">Remove Coupon</button>
              </form>
              </td>
            </tr>
              <?php endif; ?>
              <br/>
              
              
          
          <!-- /Shopping Cart Table -->
          <?php else: ?>
            <h3 class="title mb-3">No item(s) in your cart</h3>
          <?php endif; ?>  

              <a class="btn btn-success" href="<?php echo e(route('landing-page')); ?>">Continue Shopping</a><hr>

          <!-- Recently viewed-->
          <h4>Recently viewed items</h4>
          <div class="content-slider">
            <div class="swiper-container" id="popular-slider">
              <div class="swiper-wrapper">
                
                <?php for($i = 0; $i < 2; $i++): ?>
                <div class="swiper-slide">
                  <div class="row no-gutters gutters-2">

                    <?php $__currentLoopData = $recentlyViews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentlyView): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6 col-md-3 mb-2">
                      <div class="card card-product">
                        <?php echo $recentlyView->quantity < setting('site.stock_threshold') ? '<div class="badge badge-danger badge-pill">Only '.$recentlyView->quantity.' left in stock</div>' : ''; ?>

                        <a href="<?php echo e(route('shop.show', $recentlyView->slug)); ?>"><img src="<?php echo e(productImage($recentlyView->image)); ?>" alt="<?php echo e($recentlyView->name); ?> - <?php echo str_limit($recentlyView->details, 30); ?>" class="card-img-top dimg"></a>
                        <div class="card-body">
                          <span class="price">&#8358;<?php echo e(number_format( totalcash($recentlyView->price, $recentlyView->profit) )); ?></span>
                          <a href="<?php echo e(route('shop.show', $recentlyView->slug)); ?>" class="card-title h6"><?php echo e($recentlyView->name); ?> - <?php echo str_limit($recentlyView->details, 30); ?></a>
                          
                        </div>
                      </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </div>
                </div>
                <?php endfor; ?>
                
                
                
              </div>
            </div>
            <a href="#" role="button" class="carousel-control-prev" id="popular-slider-prev"><i class="fa fa-angle-left fa-lg"></i></a>
            <a href="#" role="button" class="carousel-control-next" id="popular-slider-next"><i class="fa fa-angle-right fa-lg"></i></a>
          </div>
          <!-- /Recently viewed-->

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>  


<?php $__env->startSection('required-js'); ?>
    <!-- REQUIRED JS  -->
    <script src="../plugins/jquery/jquery.min.js"></script>
    <script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>


    <!-- PLUGINS FOR CURRENT PAGE -->
    <script src="../plugins/swiper/swiper.min.js"></script>

    <!-- Mimity JS  -->
    <script src="../dist/js/script.min.js"></script>


    <!--extra js-->
    <script src="js/app.js"></script>
    <script >

        (function(){
          const classname = document.querySelectorAll('.quantity')

          Array.from(classname).forEach(function(element){
              element.addEventListener('change', function(){
                  const id = element.getAttribute('data-id')
                  const productQuantity = element.getAttribute('data-productQuantity')
                  
                    axios.patch(`/cart/${id}`, {
                    quantity: this.value,
                    productQuantity: productQuantity
                  })
                  .then(function (response) {
                    //console.log(response);
                    window.location.href = '<?php echo e(route('cart.index')); ?>'
                  })
                  .catch(function (error) {
                    //console.log(error);
                    window.location.href = '<?php echo e(route('cart.index')); ?>'
                  });
              })
          })

        })();
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ziksdxfh/ziksales/resources/views/cart.blade.php ENDPATH**/ ?>