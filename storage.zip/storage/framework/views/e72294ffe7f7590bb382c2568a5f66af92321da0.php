<?php $__env->startSection('head'); ?>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- FONT  -->
    <!-- <link rel="stylesheet" href="../fonts/fira-sans.css"> -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Fira+Sans">

    <!-- REQUIRED CSS: BOOTSTRAP, FONTAWESOME, PERFECT-SCROLLBAR  -->
    <link rel="stylesheet" href="../dist/css/vendor.min.css">


    <!-- PLUGINS FOR CURRENT PAGE -->
    <link rel="stylesheet" href="../plugins/nouislider/nouislider.min.css">

    <!-- Mimity CSS  -->
    <link rel="stylesheet" href="../dist/css/style.min.css">


    <title>My Portal | <?php echo e(config('app.name')); ?></title>
  </head>
  <?php $__env->stopSection(); ?>
  

<?php $__env->startSection('main-content'); ?>
        <div class="col" id="main-content">
          <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <!-- Category Banner -->
          <div class="card border-0 mb-3">
            <img src="../img/categories/1-wide.jpeg" alt="" class="card-img">
            <div class="card-img-overlay">
              <h2 class="card-title text-white title"><?php echo e(auth()->user()->name); ?> <?php echo e(auth()->user()->lname); ?></h2>
            </div>
          </div>
          <!-- /Category Banner -->

          <!-- List -->
          <div class="d-flex justify-content-between mt-4">
              <ul class="nav nav-pills">

                <li class="nav-item">
                  <a class="nav-link"  style="background-color: #ff6600;" href="<?php echo e(route('sell.product')); ?>">Add New Product</a>
                </li>  &nbsp;
                <div class="btn-group" role="group" aria-label="Basic example">
                  <a class="btn btn-outline-info" href="<?php echo e(route('users.edit')); ?>">Profile</a>&nbsp;
                  <a class="btn btn-outline-info" href="<?php echo e(route('orders.index')); ?>">Order</a>&nbsp;
                  <a class="btn btn-outline-info" href="<?php echo e(route('wishlist.index')); ?>">Wishlist</a>&nbsp;
                  <a class="btn btn-outline-info" href="<?php echo e(route('seller.brand')); ?>">Branding</a>
                </div>             
                
              </ul>
            
          </div>
          <div class="row no-gutters gutters-2">

            <?php if($trueSeller->count() > 0): ?>

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-6 col-sm-12 mb-2" style="<?php echo e($product->featured ? 'background-color:green' : 'background-color:orange'); ?>;">
              <div class="card card-product card-product-list">
                <a href=""><img src="<?php echo e(productImage($product->image)); ?>" alt="<?php echo $product->name; ?>" class="card-img-top"></a>
                <div class="card-body">
                  <a href="" class="card-title h5"><?php echo $product->name; ?> - <?php echo e($product->featured ? 'Product approved' : 'Product awaiting approval'); ?></a>
                  <div class="d-inline-block d-sm-block mb-2">
                    <span class="price">&#8358;<?php echo e(number_format( $product->price )); ?></span>
                  </div>
                  <p lang="zxx"><?php echo e($product->name); ?> - <?php echo str_limit($product->details, 30); ?></p>
                  <a href="<?php echo e(route('view.product', $product->slug)); ?>" style="color: white;" class="btn btn-outline-info btn-sm btn-success">View</a>
                  <a href="<?php echo e(route('update.product', $product->slug)); ?>" class="btn btn-outline-info btn-sm ">Update</a>

                  <form action="<?php echo e(route('product.destroy', $product->id)); ?>" method="post" style="display: inline;">
                      <?php echo e(csrf_field()); ?>

                      <?php echo e(method_field('Delete')); ?>

                      <button style="color: white;" onclick="alert('Are you sure you want to delete!')" class="btn btn-outline-info btn-sm btn-danger" >Delete</button>
                  </form>

                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <p>You have no item in store</p>
            <?php endif; ?>  



          </div>
          <!-- /List -->

          <!-- Pagination -->
          <nav aria-label="Page navigation Shop List">
            <ul class="pagination justify-content-center">
                <?php if($trueSeller->count() > 0): ?>
                    <?php echo e($products->appends(request()->input())->links()); ?>

                <?php endif; ?>     
            </ul>
          </nav>
          <!-- /Pagination -->

          
        </div>
    <?php $__env->stopSection(); ?>  

<?php $__env->startSection('required-js'); ?>
    <!-- REQUIRED JS  -->
    <script src="../plugins/jquery/jquery.min.js"></script>
    <script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>


    <!-- PLUGINS FOR CURRENT PAGE -->
    <script src="../plugins/nouislider/nouislider.min.js"></script>
    <script src="../plugins/raty-fa/jquery.raty-fa.min.js"></script>

    <!-- Mimity JS  -->
    <script src="../dist/js/script.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ziksdxfh/ziksales/resources/views/my-portal.blade.php ENDPATH**/ ?>