<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

    <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <head>
            <!-- Global site tag (gtag.js) - Google Analytics -->
            <script async src="https://www.googletagmanager.com/gtag/js?id=UA-130773828-1"></script>
            <script>
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());
            
              gtag('config', 'UA-130773828-1');
            </script>
            
            <meta name="theme-color" content="#ff6600">
            <link rel='shortcut icon' type='image/ico' href='<?php echo e(asset('img/blog/ziksaleslogo.ico')); ?>' /> 
            <script src="//code.jivosite.com/widget/ZJGZ5FlY12" async></script>
   
  <?php echo $__env->yieldContent('head'); ?>
  <body>

    <!--Header -->
    <header class="navbar navbar-expand navbar-light fixed-top">

      <!-- Toggle Menu -->
      <span class="toggle-menu"><i class="fa fa-bars fa-lg"></i></span>

      <!-- Logo -->
      <a class="navbar-brand" href="<?php echo e(route('landing-page')); ?>"><span><img style="width:45px; height:35px;" src="<?php echo e(asset('img/blog/ziksaleslogo.png')); ?>" alt="Ziksales Logo"></span>ZikSales</a>

      <!-- Search Form -->
      <form action="<?php echo e(route('search')); ?>" method="GET" class="form-inline form-search d-none d-sm-inline">
        <div class="input-group">
          <button class="btn btn-light btn-search-back" type="button"><i class="fa fa-arrow-left"></i></button>
          <input type="text" name="item" value="<?php echo e(request()->input('item')); ?>" class="form-control" placeholder="Search ..." aria-label="Search ...">
          <button class="btn btn-light" type="submit"><i class="fa fa-search"></i></button>
        </div>
        <?php echo e(csrf_field()); ?>

      </form>
      <!-- /Search Form -->

      <!-- navbar-nav -->
      <ul class="navbar-nav ml-auto">
        
        <!-- Search Toggle -->
        <li class="nav-item d-sm-none">
          <a href="#" class="nav-link" id="search-toggle"><i class="fa fa-search fa-lg"></i></a>
        </li>
        <!-- /Search Toggle -->

        <!-- Shopping Cart Toggle -->
        <li class="nav-item dropdown ml-1 ml-sm-3">
          <a href="#" class="nav-link" data-toggle="modal" data-target="#cartModal">
            <i class="fa fa-shopping-cart fa-lg"></i>
            <?php if(Cart::instance('default')->count() > 0): ?>
              <span class="badge badge-pink badge-count"><?php echo e(Cart::instance('default')->count()); ?></span>
            <?php endif; ?>  
          </a>
        </li>
        <!-- /Shopping Cart Toggle -->

        <!-- Notification Dropdown -->
       
        <!-- /Notification Dropdown -->

        <!-- Login Button -->
        <!-- <li class="nav-item ml-4">
          <a href="login.html" class="nav-link btn btn-light btn-sm"><i class="fa fa-sign-in"></i> Login</a>
        </li> -->
        <!-- /Login Button -->

      </ul>
      <!-- /navbar-nav -->

      <!-- User Dropdown -->
      <div class="dropdown dropdown-user">
        <a class="dropdown-toggle" href="#" role="button" id="userDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <img src="<?php echo e(asset('../img/user.png')); ?>" alt="User">
        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
          <a class="dropdown-item has-icon" href="<?php echo e(route('seller.register')); ?>"><i class="fa fa-tint fa-fw"></i> Seller's Portal</a>
          <a class="dropdown-item has-icon" href="<?php echo e(route('agent.index')); ?>"><i class="fa fa-money fa-fw"></i> Agent's Portal</a>
          <?php if(auth()->guard()->guest()): ?>
          <a class="dropdown-item has-icon" href="<?php echo e(route('login')); ?>"><i class="fa fa-sign-in fa-fw"></i> Login</a>
          <a class="dropdown-item has-icon" href="<?php echo e(route('register')); ?>"><i class="fa fa-sign-out fa-fw"></i> Register</a>
          <?php else: ?>
          <a class="dropdown-item has-icon" href="<?php echo e(route('users.edit')); ?>"><i class="fa fa-user fa-fw"></i> My Profile</a>
          <a class="dropdown-item has-icon" href="<?php echo e(route('orders.index')); ?>"><i class="fa fa-shopping-bag fa-fw"></i> My Orders</a>
          <a class="dropdown-item has-icon has-badge" href="<?php echo e(route('wishlist.index')); ?>"><i class="fa fa-heart fa-fw"></i> Wishlist <span class="badge badge-secondary"><?php echo e(Cart::instance('wishlist')->count()); ?></span></a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item has-icon " href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
            document.getElementById('logout-form').submit();"><i class="fa fa-sign-out fa-fw"></i> Sign out</a>
          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
              <?php echo csrf_field(); ?>
          </form>
          <?php endif; ?>
        </div>
      </div>
      <!-- /User Dropdown -->

    </header>
    <!-- /Header -->

    <div class="container-fluid" id="main-container">
      <div class="row">

        <!-- Sidebar -->
        <div class="col" id="main-sidebar">
          <div class="list-group list-group-flush">
            <a href="<?php echo e(route('landing-page')); ?>" class="list-group-item list-group-item-action active"><i class="fa fa-home fa-lg fa-fw"></i> Home</a>
            
            <a class="list-group-item list-group-item-action"><i class="fa fa-th fa-lg fa-fw"></i> Categories</a>

            

            <div class="panel-group" id="accordion">

              <?php $i = 0; ?>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $i++;?>
              <div class="panel panel-default">
                    <a class="list-group-item list-group-item-action <?php echo e(request()->category == $category->slug ? 'active' : ''); ?>" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($i); ?>">
                    <i class="fa fa-<?php echo e($category->icon); ?> fa-lg"></i> &nbsp;<?php echo e($category->name); ?></a>                   

                    <?php $__currentLoopData = $allSubCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allSubCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($category->id == $allSubCategory->category_id): ?>
                        <a id="collapse<?php echo e($i); ?>" href="<?php echo e(route('shop.index', ['subCategory' => $allSubCategory->name])); ?>" class="list-group-item list-group-item-action sub panel-collapse collapse in "><i class="fa fa-certificate "></i> &nbsp;<?php echo e($allSubCategory->name); ?></a>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div> 

            

            


            <a href="<?php echo e(route('about')); ?>" class="list-group-item list-group-item-action"><i class="fa fa-list fa-lg fa-fw"></i> Other Pages</a>
            <a href="<?php echo e(route('seller.register')); ?>" class="list-group-item list-group-item-action sub"><i class="fa fa-tint fa-lg fa-fw"></i> Seller's Portal</a>
            <a href="<?php echo e(route('agent.index')); ?>" class="list-group-item list-group-item-action sub"><i class="fa fa-money fa-lg fa-fw"></i> Agent's Portal</a>
            <a href="<?php echo e(route('about')); ?>" class="list-group-item list-group-item-action sub"><i class="fa fa-list-alt fa-lg"></i> &nbsp;About Us</a>
            <a href="<?php echo e(route('blog.index')); ?>" class="list-group-item list-group-item-action sub"><i class="fa fa-file-text fa-lg"></i> &nbsp;Blog</a>
            <?php if(auth()->user()): ?>
            <a href="<?php echo e(route('cart.index')); ?>" class="list-group-item list-group-item-action sub"><i class="fa fa-shopping-cart fa-lg"></i> &nbsp;Cart</a>
            <?php if(Cart::instance('default')->count() > 1): ?>
            <a href="<?php echo e(route('checkout.index')); ?>" class="list-group-item list-group-item-action sub"><i class="fa fa-certificate "></i> &nbsp;Checkout</a>
            <?php endif; ?>
            <?php if(Cart::instance('wishlist')->count() > 1): ?>
            <a href="<?php echo e(route('wishlist.index')); ?>" class="list-group-item list-group-item-action sub"><i class="fa fa-certificate "></i> &nbsp;My Wishlist</a>
            <?php endif; ?>
            <?php if(Cart::instance('compare')->count() > 1): ?>
            <a href="<?php echo e(route('compare.index')); ?>" class="list-group-item list-group-item-action sub"><i class="fa fa-certificate "></i> &nbsp;Compare</a>
            <?php endif; ?>
            <?php endif; ?>
            <a href="<?php echo e(route('contact')); ?>" class="list-group-item list-group-item-action sub"><i class="fa fa-comment fa-lg"></i> &nbsp;Contact Us</a>
            <a href="<?php echo e(route('faq')); ?>" class="list-group-item list-group-item-action sub"><i class="fa fa-question-circle fa-lg"></i> &nbsp;FAQ</a>
            

          </div>
          <div class="small p-3">Copyright © 2019 Ziksales All right reserved</div>
        </div>
        <!-- /Sidebar -->

        <?php echo $__env->yieldContent('main-content'); ?>

          

        </div>

      </div>
    </div>

    <!-- Modal Cart -->
    <div class="modal fade modal-cart" id="cartModal" tabindex="-1" role="dialog" aria-labelledby="cartModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="cartModalLabel">You have <?php echo e(Cart::instance('default')->count()); ?> item(s) in your cart</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            
            <?php if(Cart::instance('default')->count() > 0): ?>

            <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="media">
              <a href="<?php echo e(route('shop.show', $item->model->slug)); ?>"><img src="<?php echo e(productImage($item->model->image)); ?>" width="50" height="50" alt="<?php echo e($item->model->name); ?>"></a>
              <div class="media-body">
                <a href="<?php echo e(route('shop.show', $item->model->slug)); ?>" title="<?php echo e($item->model->name); ?>"><?php echo e($item->model->name); ?></a>
                
                <span class="price">&#8358;<?php echo e(number_format( totalcash($item->model->price, $item->model->profit) )); ?></span>
                
                <form action="<?php echo e(route('cart.destroy', $item->rowId)); ?>" method="POST">
                      <?php echo e(csrf_field()); ?>

                      <?php echo e(method_field('DELETE')); ?>

                      <button type="submit" class="close" aria-label="Close"><i class="fa fa-trash-o"></i></button>
                  </form>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>
            
          </div>
          <div class="modal-footer">
            <div class="box-total">
              <h4>Total: <span class="price">&#8358;<?php echo e(session()->has('coupon') ? number_format(session()->get('newTotal')) : number_format(Cart::total())); ?></span></h4>
              <a href="<?php echo e(route('cart.index')); ?>" class="btn" style="background-color: #ff751a; color: white;">VIEW CART</a>
            </div>
          </div>
        </div>
      </div>
    </div>


    <?php echo $__env->yieldContent('required-js'); ?>

  </body>
</html><?php /**PATH /home/ziksdxfh/ziksales/resources/views/layouts/app.blade.php ENDPATH**/ ?>